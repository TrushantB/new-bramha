import * as firebase from 'firebase';

const firebaseConfig = {
  apiKey: "AIzaSyAV4aGrJ6olXI2CPGQq6yb8AnZkYNPjVFQ",
  authDomain: "bramhacorp.firebaseapp.com",
  databaseURL: "https://bramhacorp.firebaseio.com",
  projectId: "bramhacorp",
  storageBucket: "bramhacorp.appspot.com",
  messagingSenderId: "182628268010",
  appId: "1:182628268010:web:a7ac3499e2d8b60084e493",
  measurementId: "G-BFS08N8DX3"
};

  firebase.initializeApp(firebaseConfig);